import boto3
import os

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    sns = boto3.client('sns')

    # Input S3 bucket and object details
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    source_key = event['Records'][0]['s3']['object']['key']

    # Output S3 bucket (from environment variables)
    destination_bucket = os.environ['OUTPUT_BUCKET']
    destination_key = f"processed/{source_key}"

    # Copy file to output bucket
    s3.copy_object(
        Bucket=destination_bucket,
        CopySource={'Bucket': source_bucket, 'Key': source_key},
        Key=destination_key
    )

    # Publish to SNS that processing is complete
    sns.publish(
        TopicArn=os.environ['SNS_TOPIC_ARN'],
        Message=f"File '{source_key}' has been processed and moved to '{destination_bucket}/{destination_key}'."
    )

    return {
        'statusCode': 200,
        'body': f"File '{source_key}' processed successfully."
    }
